import pygame
import random

pygame.init()
WIDTH, HEIGHT = 990, 780
TILE_SIZE = 30
PLAYER_SIZE = 30
ENEMY_SIZE = 30
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Battle City")
clock = pygame.time.Clock()

# Цвета
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
GRAY = (100, 100, 100)
YELLOW = (255, 255, 0)
DARK_GRAY = (70, 70, 70)

# font = pygame.font.SysFont("arial", 40)
button_font = pygame.font.SysFont("arial", 30)

game_level = 1
level_completed = False
show_next_level_button = False
next_level_button_rect = pygame.Rect(WIDTH // 2 - 180, HEIGHT // 2 - 45, 360, 90)

class GameObject(pygame.sprite.Sprite):
    def __init__(self, x, y, color, size=30):
        super().__init__()
        self.image = pygame.Surface((size, size))
        self.image.fill(color)
        self.rect = self.image.get_rect(topleft=(x, y))

    def die(self):
        self.image.fill(GRAY)

class Player(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, (255, 255, 255), TILE_SIZE)
        self.base_image = pygame.image.load("player_enemy/Player.png")
        self.image = pygame.transform.scale(self.base_image, (PLAYER_SIZE, PLAYER_SIZE))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.speed = 3
        self.last_shot = 0
        self.last_direction = (0, -1)
        self.is_alive = True

    def update(self, keys):
        if not self.is_alive:
            return

        dx = dy = 0

        if keys[pygame.K_a]: dx = -self.speed
        elif keys[pygame.K_d]: dx = self.speed
        elif keys[pygame.K_w]: dy = -self.speed
        elif keys[pygame.K_s]: dy = self.speed

        if dx != 0 or dy != 0:
            self.last_direction = (dx // abs(dx) if dx else 0, dy // abs(dy) if dy else 0)

        self.rect.x += dx
        if self.rect.left < 0 or self.rect.right > WIDTH or \
           pygame.sprite.spritecollide(self, walls, False) or \
           pygame.sprite.spritecollide(self, hard_walls, False):
            self.rect.x -= dx

        self.rect.y += dy
        if self.rect.top < 0 or self.rect.bottom > HEIGHT or \
           pygame.sprite.spritecollide(self, walls, False) or \
           pygame.sprite.spritecollide(self, hard_walls, False):
            self.rect.y -= dy

        if self.last_direction == (1, 0):
            self.image = pygame.transform.rotate(self.base_image, -90)
        elif self.last_direction == (-1, 0):
            self.image = pygame.transform.rotate(self.base_image, 90)
        elif self.last_direction == (0, 1):
            self.image = pygame.transform.rotate(self.base_image, 180)
        elif self.last_direction == (0, -1):
            self.image = self.base_image

        self.image = pygame.transform.scale(self.image, (PLAYER_SIZE, PLAYER_SIZE))
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))

    def shoot(self):
        if not self.is_alive:
            return

        now = pygame.time.get_ticks()
        if now - self.last_shot > 500:
            bullet = Bullet(self.rect.centerx, self.rect.centery, self.last_direction)
            bullets.add(bullet)
            all_sprites.add(bullet)
            self.last_shot = now

    def die(self):
        self.is_alive = False
        self.image.fill(GRAY)

class Enemy(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, (255, 255, 255), TILE_SIZE)
        self.base_image = pygame.image.load("player_enemy/Enemy.png")
        self.image = pygame.transform.scale(self.base_image, (PLAYER_SIZE, PLAYER_SIZE))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.dir = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        self.move_delay = 0
        self.speed = 8
        self.last_shot = pygame.time.get_ticks()
        self.shoot_delay = random.randint(1000, 3000)
        self.last_direction = self.dir
        self.last_turn_time = pygame.time.get_ticks()
        self.turn_delay = random.randint(3000, 7000)

    def update(self):
        if self.image.get_at((0, 0)) == GRAY:
            return

        current_time = pygame.time.get_ticks()
        if current_time - self.last_turn_time >= self.turn_delay:
            self.dir = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
            self.last_turn_time = current_time
            self.turn_delay = random.randint(3000, 7000)

        self.move_delay += 1
        if self.move_delay > 20:
            self.rect.x += self.dir[0] * self.speed
            self.rect.y += self.dir[1] * self.speed
            if self.rect.left < 0 or self.rect.right > WIDTH or \
               self.rect.top < 0 or self.rect.bottom > HEIGHT or \
               pygame.sprite.spritecollide(self, walls, False) or \
               pygame.sprite.spritecollide(self, hard_walls, False):
                self.rect.x -= self.dir[0] * self.speed
                self.rect.y -= self.dir[1] * self.speed
                self.dir = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
            self.last_direction = self.dir
            self.move_delay = 0

        if self.last_direction == (1, 0):
            self.image = pygame.transform.rotate(self.base_image, -90)
        elif self.last_direction == (-1, 0):
            self.image = pygame.transform.rotate(self.base_image, 90)
        elif self.last_direction == (0, 1):
            self.image = pygame.transform.rotate(self.base_image, 180)
        elif self.last_direction == (0, -1):
            self.image = self.base_image

        self.image = pygame.transform.scale(self.image, (PLAYER_SIZE, PLAYER_SIZE))
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))

        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.shoot()
            self.last_shot = now
            self.shoot_delay = random.randint(1000, 3000)

    def shoot(self):
        bullet = EnemyBullet(self.rect.centerx, self.rect.centery, self.last_direction)
        enemy_bullets.add(bullet)
        all_sprites.add(bullet)

    def die(self):
        self.image.fill(GRAY)

class Bullet(GameObject):
    def __init__(self, x, y, direction):
        super().__init__(x, y, YELLOW, 10)
        self.speed = 5
        self.dx, self.dy = direction

    def update(self):
        self.rect.x += self.dx * self.speed
        self.rect.y += self.dy * self.speed
        if self.rect.left <= 0 or self.rect.right >= WIDTH or \
           self.rect.top <= 0 or self.rect.bottom >= HEIGHT:
            self.kill()
        if pygame.sprite.spritecollide(self, walls, True) or \
           pygame.sprite.spritecollide(self, hard_walls, False):
            self.kill()

class EnemyBullet(GameObject):
    def __init__(self, x, y, direction):
        super().__init__(x, y, YELLOW, 10)
        self.speed = 4
        self.dx, self.dy = direction

    def update(self):
        self.rect.x += self.dx * self.speed
        self.rect.y += self.dy * self.speed
        if self.rect.left <= 0 or self.rect.right >= WIDTH or \
           self.rect.top <= 0 or self.rect.bottom >= HEIGHT:
            self.kill()
        if pygame.sprite.spritecollide(self, walls, True) or \
           pygame.sprite.spritecollide(self, hard_walls, False):
            self.kill()

class Wall(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, (255, 255, 255), TILE_SIZE)
        self.image = pygame.image.load("Blocks/photo_2025-04-10_20-52-22.jpg")
        self.image = pygame.transform.scale(self.image, (TILE_SIZE, TILE_SIZE))
        self.rect = self.image.get_rect(topleft=(x, y))

class HardWall(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, (255, 255, 255), TILE_SIZE)
        self.image = pygame.image.load("Blocks/photo_2025-04-10_20-51-11.jpg")
        self.image = pygame.transform.scale(self.image, (TILE_SIZE, TILE_SIZE))
        self.rect = self.image.get_rect(topleft=(x, y))

class InvisibilityBlock(GameObject):
    def __init__(self, x, y):
        super().__init__(x, y, (255, 255, 255), TILE_SIZE)
        self.image = pygame.image.load("Blocks/photo_2025-04-11_15-26-49.jpg")
        self.image = pygame.transform.scale(self.image, (TILE_SIZE, TILE_SIZE))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.image.set_alpha(100)  # Прозрачный блок

player = None
enemies = pygame.sprite.Group()
walls = pygame.sprite.Group()
hard_walls = pygame.sprite.Group()
invisibility_blocks = pygame.sprite.Group()
bullets = pygame.sprite.Group()
enemy_bullets = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()

maps = ["maps/map.txt", "maps/map2.txt"]

def load_map(map_file):
    global player
    enemy_spawn_positions = []
    with open(map_file) as f:
        map_data = f.readlines()
    for row_index, row in enumerate(map_data):
        for col_index, char in enumerate(row.strip("\n")):
            x = col_index * TILE_SIZE
            y = row_index * TILE_SIZE
            if char == "#":
                wall = Wall(x, y)
                walls.add(wall)
                all_sprites.add(wall)
            elif char == "X":
                hard_wall = HardWall(x, y)
                hard_walls.add(hard_wall)
                all_sprites.add(hard_wall)
            elif char == "P":
                player = Player(x, y)
                all_sprites.add(player)
            elif char == "E":
                enemy_spawn_positions.append((x, y))
            elif char == "I":
                block = InvisibilityBlock(x, y)
                invisibility_blocks.add(block)
                all_sprites.add(block)
    return enemy_spawn_positions

def main():
    global player, enemies, bullets, enemy_bullets, all_sprites
    global last_enemy_spawn_time, enemy_spawn_delay, enemy_spawn_count
    global defeated_enemy_count, level_completed, show_next_level_button
    global game_level, selected_map, enemy_spawn_positions

    defeated_enemy_count = 0
    level_completed = False
    show_next_level_button = False
    enemy_spawn_count = 0
    last_enemy_spawn_time = 0
    enemy_spawn_delay = 4000
    max_enemy_count = 5

    enemies.empty()
    bullets.empty()
    enemy_bullets.empty()
    all_sprites.empty()
    walls.empty()
    hard_walls.empty()

    selected_map = maps[game_level - 1]
    enemy_spawn_positions = load_map(selected_map)

    running = True
    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN and not level_completed:
                if event.key == pygame.K_SPACE and player:
                    player.shoot()
            if event.type == pygame.MOUSEBUTTONDOWN and level_completed and show_next_level_button:
                if next_level_button_rect.collidepoint(event.pos):
                    if game_level < len(maps):
                        game_level += 1
                        main()
                    else:
                        running = False

        if not level_completed:
            keys = pygame.key.get_pressed()
            if player:
                player.update(keys)

            current_time = pygame.time.get_ticks()
            if current_time - last_enemy_spawn_time >= enemy_spawn_delay and enemy_spawn_count < max_enemy_count:
                x, y = random.choice(enemy_spawn_positions)
                enemy = Enemy(x, y)
                enemies.add(enemy)
                all_sprites.add(enemy)
                last_enemy_spawn_time = current_time
                enemy_spawn_count += 1

            for enemy in enemies:
                if pygame.sprite.spritecollide(enemy, bullets, True):
                    defeated_enemy_count += 1
                    enemies.remove(enemy)
                    all_sprites.remove(enemy)

            if defeated_enemy_count >= 5:
                level_completed = True
                show_next_level_button = True

        bullets.update()
        enemies.update()
        enemy_bullets.update()

        if player and pygame.sprite.spritecollide(player, enemies, True):
            player.die()
        if player and pygame.sprite.spritecollide(player, enemy_bullets, True):
            player.die()

        if player:
            if pygame.sprite.spritecollide(player, invisibility_blocks, False):
                pass
                player.image.set_alpha(0)
            else:
                pass
                player.image.set_alpha(255)

        win.fill(BLACK)
        all_sprites.draw(win)
        bullets.draw(win)
        enemy_bullets.draw(win)

        if level_completed:
            if show_next_level_button:
                pygame.draw.rect(win, DARK_GRAY, next_level_button_rect)
                button_text = button_font.render(f"Перейти на уровень {game_level + 1}", True, YELLOW)
                text_rect = button_text.get_rect(center=next_level_button_rect.center)
                win.blit(button_text, text_rect)

        pygame.display.flip()

    pygame.quit()

main()